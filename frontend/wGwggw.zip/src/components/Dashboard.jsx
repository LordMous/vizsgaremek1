import React, { useEffect, useState } from 'react';
import authService from '../services/authService';

function Dashboard() {
  const [chats, setChats] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const currentUser = authService.getCurrentUser();

  useEffect(() => {
    const fetchChats = async () => {
      try {
        const response = await authService.getChats();
        setChats(response.data);
      } catch (error) {
        console.error('Error fetching chats', error);
      }
    };

    if (currentUser) {
      fetchChats();
    }
  }, [currentUser]);

  const fetchMessages = async (chatId) => {
    try {
      const response = await authService.getMessages(chatId);
      setMessages(response.data);
    } catch (error) {
      console.error('Error fetching messages', error);
    }
  };

  const handleChatClick = (chat) => {
    setSelectedChat(chat);
    fetchMessages(chat.id);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    try {
      await authService.sendMessage(selectedChat.id, newMessage);
      setNewMessage('');
      fetchMessages(selectedChat.id);
    } catch (error) {
      console.error('Error sending message', error);
    }
  };

  if (!currentUser) {
    return <div>Please log in to view your dashboard.</div>;
  }

  return (
    <div>
      <h1>Dashboard</h1>
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1 }}>
          <h2>Chats</h2>
          <ul>
            {chats.map((chat) => (
              <li key={chat.id} onClick={() => handleChatClick(chat)}>
                Chat with {chat.user1 && chat.user1.userName === currentUser.userName ? chat.user2.userName : chat.user1 && chat.user1.userName }
              </li>
            ))}
          </ul>
        </div>
        <div style={{ flex: 2 }}>
          {selectedChat && (
            <>
              <h2>Messages</h2>
              <ul>
                {messages.map((message) => (
                  <li key={message.createdAt}>
                    <strong>{message.sender}:</strong> {message.message}
                  </li>
                ))}
              </ul>
              <form onSubmit={handleSendMessage}>
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  required
                />
                <button type="submit">Send</button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;